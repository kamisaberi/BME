import mysql.connector
import json
import inflect
import os


class Database:
    connection = None
    cursor = None
    db_nam = None
    sql_templates = []
    table_templates = []

    def __init__(self, db_name):
        self.db_name = db_name
        self.sql_templates = json.load(open('../resources/templates/sql.json', 'r'))
        self.table_templates = json.load(open('../resources/templates/templates.json', 'r'))

    def open(self):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database=self.db_name
        )
        self.connection = mydb

    def close(self):
        self.connection.close()

    def install(self):
        tables = json.load(open(os.path.dirname(os.path.abspath(__file__)) + "/" + '../resources/database/backend.json', 'r'))
        engine = inflect.engine()
        for table in tables["tables"]:
            fn = str.format(self.sql_templates["table.create"], table_name=str(table["title"]), fields=",".join(table["fields"]))
            self.connection.cursor.execute(fn)

            if table['has_property_table'] == True:
                template = self.table_templates['properties']
                fn = str.format(self.sql_templates["table.create"], table_name=str.format(template["title"], engine.singular_noun(table["title"])),
                                fields=",".join(template["fields"]))
                self.connection.cursor.execute(fn)
                template = self.table_templates['assigned_properties']
                fn = str.format(self.sql_templates["table.create"], table_name=str.format(template["title"], engine.singular_noun(table["title"])),
                                fields=",".join(template["fields"]))
                self.connection.cursor.execute(fn)

            if table['has_setting_table'] == True:
                template = self.table_templates['settings']
                fn = str.format(self.sql_templates["table.create"], table_name=str.format(template["title"], engine.singular_noun(table["title"])),
                                fields=",".join(template["fields"]))
                self.connection.cursor.execute(fn)
                template = self.table_templates['assigned_settings']
                fn = str.format(self.sql_templates["table.create"], table_name=str.format(template["title"], engine.singular_noun(table["title"])),
                                fields=",".join(template["fields"]))
                self.connection.cursor.execute(fn)

        for relation in tables['relations']:
            tbls = relation['tables']
            template = self.table_templates[relation['template']]
            table_name = str.format(template['title'], tbls)

            fields = template['fields'].copy()

            for i, s in enumerate(fields):
                fields[i] = str.format(fields[i], tbls)

            if 'extra_fields' in relation:
                fields = fields + relation['extra_fields']
            # fields = str.format(template['fields'], tbls)

            fn = str.format(self.sql_templates["table.create"], table_name=table_name, fields=",".join(fields))
            self.connection.cursor.execute(fn)

        self.connection.close()

    def update(self, table, item_id, data):
        print("hello world")
