import mysql.connector
import json
import inflect
from include.Templates import *


class Field:

    def get_fields(table, connection=None):
        connection.cursor().execute(str.format(Templates.sqls['table.get.fields'], table_name=table))
        return connection.cursor.fetchall()

    def get_available_fields(table, data, connection=None):
        all_fields = Field.get_fields(table, connection)
        fields = {}
        for field in all_fields:
            if field[0] in data:
                fields[field[0]] = data[field[0]]
        return fields
