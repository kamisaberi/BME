import mysql.connector
import json
import inflect
import os


class Templates:
    sqls = {}
    tables = {}

    @staticmethod
    def initialize():
        Templates.sqls = json.load(open(os.path.dirname(os.path.abspath(__file__)) + "/" + "../resources/templates/sql.json"))
        Templates.tables = json.load(open(os.path.dirname(os.path.abspath(__file__)) + "/" + "../resources/templates/templates.json"))
